package audioplayer.player.listener;

import audioplayer.player.AudioProcessingLayer;


public class PlayerEvent {

	private AudioProcessingLayer ppl;
	
	public PlayerEvent(AudioProcessingLayer ppl) {
		super();
		this.ppl = ppl;
	}

	public AudioProcessingLayer getPlayerProcessingLayer() {
		return ppl;
	}

	
}
