package audioplayer.player.listener;

public interface PlayerListener {

	public void onPlayerStart(PlayerEvent event);
	
	public void onPlayerStop(PlayerEvent event);
	
	public void onPlayerNextSong(PlayerEvent event);
	
	public void onPlayerVolumeChange(PlayerEvent event);

	public void onPlayerPositionChange(PlayerEvent event);
	
}
